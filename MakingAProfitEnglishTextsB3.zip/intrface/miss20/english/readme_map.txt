; NOTE FOR TRANSLATORS: this is the text that is drawn on
; the map, for translating. I only need the text translated,
; and I'll update the images. Thanks!

;--------------------------------------
; Page 0

"My place - the angel near the pub. Hole up here if you have any guard trouble. -- Argaux"

"Fountain - meet me here!"

"Fishmonger"

"Hammerites"

"Cemetery"

"di Rupo manor"

;--------------------------------------
; Page 1

"Hammerite Sanctuary"

"Library"

"Warden"

"Priest"

"Work room"

"Chapel"

"Basement & crypt"
